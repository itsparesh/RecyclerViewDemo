package com.example.recyclerviewtask;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView nameListRV = findViewById(R.id.dataRV);

        // set up the RecyclerView
        nameListRV.setLayoutManager(new LinearLayoutManager(this));
        RecyclerViewAdapter nameListRVAdapter = new RecyclerViewAdapter(prepareNameDataList());
        nameListRV.setAdapter(nameListRVAdapter);
    }

    private ArrayList<NameData> prepareNameDataList() {
        ArrayList<NameData> nameDataArrayList = new ArrayList<>();
        NameData nameData = new NameData();

        nameData.setFirstName("Paresh");
        nameData.setLastName("Sharma");
        nameDataArrayList.add(nameData);

        nameData = new NameData();
        nameData.setFirstName("Lionel");
        nameData.setLastName("Messi");
        nameDataArrayList.add(nameData);

        nameData = new NameData();
        nameData.setFirstName("Robert");
        nameData.setLastName("Lewandowski");
        nameDataArrayList.add(nameData);

        nameData = new NameData();
        nameData.setFirstName("Cristiano");
        nameData.setLastName("Ronaldo");
        nameDataArrayList.add(nameData);

        nameData = new NameData();
        nameData.setFirstName("Luke");
        nameData.setLastName("Shaw");
        nameDataArrayList.add(nameData);

        nameData = new NameData();
        nameData.setFirstName("Sergio");
        nameData.setLastName("Ramos");
        nameDataArrayList.add(nameData);

        nameData = new NameData();
        nameData.setFirstName("Luka");
        nameData.setLastName("Modric");
        nameDataArrayList.add(nameData);

        nameData = new NameData();
        nameData.setFirstName("Marco");
        nameData.setLastName("Reus");
        nameDataArrayList.add(nameData);

        nameData = new NameData();
        nameData.setFirstName("Thomas");
        nameData.setLastName("Muller");
        nameDataArrayList.add(nameData);

        nameData = new NameData();
        nameData.setFirstName("Harry");
        nameData.setLastName("Kane");
        nameDataArrayList.add(nameData);

        return nameDataArrayList;
    }
}
